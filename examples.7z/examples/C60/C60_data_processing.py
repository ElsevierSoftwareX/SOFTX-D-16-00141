import sys
sys.path.append('../../')
import XaNSoNS
import numpy as np
from scipy import interpolate, optimize
from matplotlib import pyplot as plt
wavelength=1.67 #neutron source wavelength in Angstrom
exp_data=np.loadtxt('experiment.txt')#loading the experimental diffraction pattern
theta_exp=exp_data[:,0]
q_exp=4.*np.pi*np.sin(theta_exp/360.*np.pi)/wavelength
pattern_exp=exp_data[:,1]
XaNSoNS.formfactors('C60.xml','')#creating the file with form factors
config=XaNSoNS.config('C60.xml')#loading the initial configuration of parameters
Uiso_list=[0,0.033,0.066]#3 variants for the atomic displacement patameter
Ncell_list=range(10,18)#8 variants for the nanocrystal sizes in terms of the number of unit cells
sim_data=[np.ones(theta_exp.size)]#1st element in the list is for the constant background
labels=[]
for Uiso in Uiso_list:
    for Atom in config.Block[0].Atoms.Atom:
        Atom.Uiso=Uiso#setting the atomic displacement parameter for an atom    
    for Ncell in Ncell_list:
        config.Block[0].CellVectors.N=Ncell*np.ones(3)#setting the number of unit cells
        #setting the new name for the simulation
        config.Calculation.name='C60_%dx%dx%d_Uiso_%.3f'%(Ncell,Ncell,Ncell,Uiso)
        labels.append(config.Calculation.name)
        XMLname='%s.xml'%config.Calculation.name
        config.ToXML(XMLname)#saving the configuration to the XML file
        #running the simulation
        XaNSoNS.run(XMLname, version='OpenCL',CIFcheck=False,FFcheck=False).wait()
        filename=config.Calculation.name+'_%s_1D.txt'%config.Calculation.source.lower()[:4]
        data=np.loadtxt(filename)#loading the results
        data_interp=interpolate.interp1d(data[:,0],data[:,1])#interpolating the data
        #convoluting with the instrument function (delta(q)/q=0.02)
        data_corrected=np.zeros(q_exp.size)
        for i in range(q_exp.size):
            sigma=0.02/2.355*q_exp[i]
            q1,dq=np.linspace(q_exp[i]-3.5*sigma,q_exp[i]+3.5*sigma,100,retstep=True)
            IF=np.exp(-(q_exp[i]-q1)**2/(2.*sigma**2))/(sigma*np.sqrt(2.*np.pi))
            data_corrected[i]=(data_interp(q1)*IF).sum()*dq
        sim_data.append(data_corrected)#storing the corrected data to the list
sim_data=np.array(sim_data).T#converting list to numpy array and trasposing
x,norm=optimize.nnls(sim_data[90:,:],pattern_exp[90:])#solving the problem
#plotting the results
fig=plt.figure(1)
ax=fig.add_subplot(111)
ax.plot(q_exp,pattern_exp,'-k',label='experiment')
ax.plot(q_exp,sim_data.dot(x),'-b',label='theory')
ax.set_xlabel('q, A$^{-1}$')
ax.set_ylabel('S, a.u.')
ax.set_xlim(q_exp[0],q_exp[-1])
ax.legend(loc=1,frameon=False)
#printing the values
background=x[0]
frac=100*x[1:]/x[1:].sum()#getting the percentage
step=0
ax.text(0.3,0.75,'background: %d a.u.'%background,transform=ax.transAxes)
for i in range(frac.size):
    if frac[i]>0.1:#printing only if the fraction is greater than 0.1%
        ax.text(0.3,0.7-step,labels[i]+': %.1f %%'%frac[i],transform=ax.transAxes)
        step+=0.05
fig.savefig('results.png',dpi=300)
plt.show()